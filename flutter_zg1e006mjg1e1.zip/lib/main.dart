import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
void main() {
  runApp(const SimplePortfolioApp());
}

class SimplePortfolioApp extends StatelessWidget {
 const SimplePortfolioApp({Key? key}) : super(key: key);

  @override
Widget build(BuildContext context){
 return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Portfolio',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFF5F5F5),
      ),
      home: HomePage(),
 );

}
}

class HomePage extends StatefulWidget{
  const HomePage({Key? key}) : super(key:key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String selectedPage = 'Home' ;
  late ScrollController _scrollController;

@override
void initState(){
  super.initState();
  _scrollController = ScrollController();
}

Widget _buildContent() {
  if (selectedPage == 'Home') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ClipOval(
          child: Image.asset(
            'lib/assets/images/profile.jpg',
            width: 120,
            height: 120,
            fit: BoxFit.cover,
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Steven Reyes',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'Flutter Developer',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  if (selectedPage == 'About') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
            'lib/assets/images/wan.jpg',
            width: 120,
            height: 120,
            fit: BoxFit.cover,
          ),
        SizedBox(height: 64),
        Text(
          'ABOUT ME',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'A student in STI that wants to learn skills that will help  him to earn for his family. A person  who can work in any environment as long as he has the tools and instructions that  he needs to done. A developer that can learn  to  his  mistakes and wants  the  best outcome whenever he has any projects woking on. A type of person who wants a  complete scheduled  tasks that he needs to done. Also, he is a  type of person who take challenges as a  stepping stone for his  success.',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  if (selectedPage == 'Skills') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
            'lib/assets/images/mem.jpg',
            width: 120,
            height: 120,
            fit: BoxFit.cover,
          ),
        SizedBox(height: 64),
        Text(
          'ABOUT ME',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          '- Programming',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
        Text(
          '- Critical Thinking',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  
  }
  else if (selectedPage == 'Contact') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
            'lib/assets/images/mem.jpg',
            width: 120,
            height: 120,
            fit: BoxFit.cover,
          ),
        SizedBox(height: 64),
        Text(
          'CONTACTS',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          '- Email: steven.reyes.0324@gmail.com',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[700],
          ),
        ),
        Text(
          '- Contact Number: 09473810107',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[700],
          ),
        ),
        Text(
          '- Facebook: Steven Reyes',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[700],
          ),
        ),
      ],
    );
  
  }
    return Text('Coming soon: $selectedPage');

}

@override
Widget build(BuildContext context){
  return Scaffold(
    backgroundColor: Color(0xFFF5F5F5),
    appBar: AppBar(
      leading: Builder(
        builder: (BuildContext context){
          return IconButton(
            icon: Icon(Icons.menu),
            onPressed: (){
              Scaffold.of(context).openDrawer();
            },
          );
        },
      ),
      backgroundColor: Color.fromARGB(223, 11, 9, 77),
      title: Text('Portfolio',
        style:GoogleFonts.montserrat(
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    drawer: Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 21, 91, 148),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [ClipOval(
                child:
              Image.asset('lib/assets/images/profile.jpg', 
              width: 80,
              height: 80,
              fit: BoxFit.cover,
              )),
                Text('Steven Reyes',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                ),
                SizedBox(height: 4,),
                Text('Flutter Developer',
                style: GoogleFonts.roboto(
                  fontSize: 14,
                  color: Colors.white70,
                ),
                )
              ],
            ),
          ),
          ListTile(
           leading: Icon(Icons.home, color: Colors.blue),
           title: Text('Home'),
           onTap: () {
              Navigator.pop(context);
              setState(() {
                selectedPage = 'Home';
                
              });
            },
          ),
           ListTile(
            leading: Icon(Icons.person, color: Colors.blue),
            title: Text('About'),
            onTap: () {
               Navigator.pop(context);
               setState(() {
                selectedPage = 'About';


              });
            },
          ),
            ListTile(
              leading: Icon(Icons.lightbulb, color: Colors.blue),
              title: Text('Skills'),
              onTap: () {
                Navigator.pop(context);
                  setState(() {
                  selectedPage = 'Skills';
                });
              },
            ),
            ListTile(
              leading: Icon(Icons.email, color: Colors.blue),
              title: Text('Contact'),
              onTap: () {
                Navigator.pop(context);
                  setState(() {
                    selectedPage = 'Contact';
                  });
                },
              ),
              Divider(),
              ListTile(
                leading: Icon(Icons.download, color: Colors.blue),
                title: Text('Download Resume'),
                onTap: () {
                  Navigator.pop(context);
                  print('Download Resume tapped');
                },
              ),
        ],
      ),
    ),
    body: SingleChildScrollView(
  controller: _scrollController,
  child: Padding(
    padding: EdgeInsets.all(20),
    child: Center(
      child: _buildContent(),
    ),
  ),
),
  );
}



@override
void dispose(){
  _scrollController.dispose();
  super.dispose();
}


}


